
var krms_config ={	
	'ApiUrl':"http://www.makanku.com/resto/mobileapp/api",
	'DialogDefaultTitle':"MAKANKU",
	'pushNotificationSenderid':"1058896182661",
	'facebookAppId':"1702077666739633"
};